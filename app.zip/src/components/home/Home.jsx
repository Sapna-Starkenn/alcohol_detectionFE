import React, { useRef, useState, useEffect } from "react";
import gif from "../../assets/images/RoadAn.mp4";
import car from "../../assets/images/car3.png";
import speedIcon from "../../assets/images/speed.png";
import accelIcon from "../../assets/images/accel.png";
import alcoholIcon from "../../assets/images/alcohol.png";
import greenIcon from "../../assets/images/green.png";
import redIcon from "../../assets/images/red.png";
import logo from "../../assets/images/logo.png";

function Home() {
  const videoRef = useRef(null);
  const [speed, setSpeed] = useState(1); // Initial playback speed
  const [acceleration, setAcceleration] = useState(true);
  const [isAlcohol, setIsAlcohol] = useState(false);

  useEffect(() => {
    if (isAlcohol) {
      handleSlowStop();

      setAcceleration(false);
    }
    // eslint-disable-next-line
  }, [isAlcohol]);

  const handlePause = () => {
    videoRef.current.pause();
  };

  const handleAlcohol = () => {
    setIsAlcohol(!isAlcohol);
  };

  const handlePlay = () => {
    setIsAlcohol(false);
    setAcceleration(true);

    setSpeed(1);
    videoRef.current.play();
  };

  const handleIncreaseSpeed = () => {
    const newSpeed = speed + 0.5; // Increase speed by 0.5x
    setSpeed(newSpeed);
    videoRef.current.playbackRate = newSpeed;
  };

  const handleSlowStop = () => {
    const decreaseAmount = speed / 30; // Amount to decrease per 100ms to reach zero in 3 seconds
    let currentSpeed = speed;

    const decreaseInterval = setInterval(() => {
      currentSpeed -= decreaseAmount;
      if (currentSpeed <= 0) {
        currentSpeed = 0;
        clearInterval(decreaseInterval);
      }
      videoRef.current.playbackRate =
        Number(currentSpeed.toFixed(2)) < 1
          ? 1
          : Number(currentSpeed.toFixed(2));
      setSpeed(Number(currentSpeed.toFixed(2)));
      console.log(`Current speed: ${currentSpeed.toFixed(2)}`); // Display current speed (you can replace this with your desired action)
    }, 100); // Runs every 100ms

    setTimeout(() => {
      clearInterval(decreaseInterval);
      console.log("Speed reached zero");
      handlePause();
      setSpeed(0);
    }, 3000); // Stops the decrease after 3 seconds
  };

  const handleReduceSpeed = () => {
    handleSlowStop();
  };

  // let data = {
  //   timestamp: new Date().getTime(),
  //   speed: speed,
  //   isAlcohol: false,
  // };

  return (
    <div>
      <img src={logo} alt='Brand Logo' className='logo' />
      <video
        ref={videoRef}
        autoPlay
        loop
        muted
        style={{ width: "100vw", height: "100vh" }}
      >
        <source src={gif} type='video/mp4' />
        Your browser does not support the video tag.
      </video>

      <div className='car2'>
        {/* Speed */}
        <div style={{ display: "flex", alignItems: "center" }}>
          <img
            src={speedIcon}
            height='50px'
            style={{ verticalAlign: "center" }}
            alt='Speed Icon'
          />{" "}
          <p
            className='speed'
            style={{ verticalAlign: "center", marginLeft: "10px" }}
          >
            {(speed * 20).toFixed(2)} km/h
          </p>
        </div>
        {/* Alcohol */}
        <div style={{ display: "flex", alignItems: "center" }}>
          <img
            src={alcoholIcon}
            height='50px'
            style={{ verticalAlign: "center" }}
            alt='Alcohol Icon'
          />{" "}
          <p className='speed' style={{ verticalAlign: "center" }}>
            {isAlcohol ? (
              <div style={{ display: "flex" }}>
                <img
                  src={greenIcon}
                  height='30px'
                  style={{ verticalAlign: "center" }}
                  alt='Green Icon'
                />
                <small style={{ fontSize: "18px" }}>Alcohol Detected</small>
              </div>
            ) : (
              <div style={{ display: "flex" }}>
                <img
                  src={redIcon}
                  height='30px'
                  style={{ verticalAlign: "center" }}
                  alt='Red Icon'
                />
                <small style={{ fontSize: "18px" }}>Alcohol Not Detected</small>
              </div>
            )}
          </p>
        </div>

        {/* Alcohol */}
        <div style={{ display: "flex", alignItems: "center" }}>
          <img
            src={accelIcon}
            height='50px'
            style={{ verticalAlign: "center" }}
            alt='Accelration Icon'
          />{" "}
          <p className='speed' style={{ verticalAlign: "center" }}>
            {acceleration ? (
              <div style={{ display: "flex" }}>
                <img
                  src={greenIcon}
                  height='30px'
                  style={{ verticalAlign: "center" }}
                  alt='Green Icon'
                />
                <small style={{ fontSize: "18px" }}>Acceleration ON</small>
              </div>
            ) : (
              <div style={{ display: "flex" }}>
                <img
                  src={redIcon}
                  height='30px'
                  style={{ verticalAlign: "center" }}
                  alt='Red Icon'
                />
                <small style={{ fontSize: "18px" }}>Acceleration Cut OFF</small>
              </div>
            )}
          </p>
        </div>
      </div>

      <img src={car} alt='roadgif' className='car'></img>
      <div className='car3'>
        <button className='btn' onClick={handlePause}>
          Stop
        </button>
        <button className='btn' onClick={handlePlay}>
          Reset
        </button>
        <button className='btn' onClick={handleIncreaseSpeed}>
          Increase Speed
        </button>
        <button className='btn' onClick={handleReduceSpeed}>
          Reduce Speed
        </button>
        <button className='btn' onClick={handleAlcohol}>
          Alcohol Toggle
        </button>
      </div>
    </div>
  );
}

export default Home;
